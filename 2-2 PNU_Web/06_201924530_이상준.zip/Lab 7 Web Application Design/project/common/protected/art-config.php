<?php
define('DBCONNECTION', 'mysql:host=localhost;dbname=art');
define('DBUSER', 'testuser2');
define('DBPASS', 'mypassword');

define('DBHOST', 'localhost');
define('DBNAME', 'art');

?>
