<?php
define('DBCONNECTION', 'mysql:host=localhost;dbname=books');
define('DBUSER', 'test');
define('DBPASS', 'mypassword');



?>
