<?php
define('DBCONNECTION', 'mysql:host=localhost;dbname=travels');
define('DBUSER', 'testuser3');
define('DBPASS', 'mypassword');



?>
